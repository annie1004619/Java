package lab01;

public class Sorry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Sorry~~");
		System.out.println("��վ �̾��մϴ�~~");
		System.out.println("1711412 ������");

	}

}
